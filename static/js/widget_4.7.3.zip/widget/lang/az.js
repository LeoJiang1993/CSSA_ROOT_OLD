/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'widget', 'az', {
	'move': 'Tıklayın və aparın',
	'label': '%1 vidjet'
} );
